# v1.2 (2023-09-22)

* Updated module.json for Foundry version 11.

# v1.1 (2023-01-02)

* Added Character Level to Recipe Items.
* Updated documentation.

# v1.0 (2023-01-01)

* Initial Release.
