# Crafting and Gathering
Crafting and Gathering for DND 5e.

Dependencies.
* Foundry 10.291
* DND5e System 2.0.3
* Advanced Macros 1.18.1
* Compendium Folders 2.5.6
* Gatherer 1.4
* Item Containers 10.0.4
* Item Piles 2.3.7
* Mastercrafted 1.5.3

<i>Nokturnel</i>